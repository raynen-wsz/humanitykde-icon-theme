Humanity KDE Icon Theme

Version: 0.2.5
Date: December 2025
Author: raynen

### Overview ####
Humanity KDE Icon Theme is a custom icon theme designed specifically for KDE Plasma. All icons are reated in SVG format, also some icons were updated and recolorized
Around 25% of the icons have been replaced.

### Installation ###
Copy the Humanity KDE folder to your icon themes directory:

For a single user: ~/.local/share/icons/
For system-wide: /usr/share/icons/
Apply and enjoy the refreshed icon theme.

### Notes ###
Icons are free to use for personal or commercial purposes.

https://github.com/raynen-wsz/humanitykde-icon-theme
